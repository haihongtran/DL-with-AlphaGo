﻿# EE488B Special Topics in EE <Deep Learning and AlphaGo>, Fall 2017
# Information Theory & Machine Learning Lab, School of EE, KAIST

from boardgame import game1, game2, game3, game4, data_augmentation

game = game4()
game.play_interactive([],0,[],0)

